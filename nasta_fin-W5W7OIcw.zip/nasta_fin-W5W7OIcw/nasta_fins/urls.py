from django.urls import path
from .views import topics, topic, new_topic, index, new_entry, edit_entry

app_name = 'nasta_fins'
urlpatterns = [
     path('', index, name='index'),
     path('topics/', topics, name='topics'),
     path('topic/<int:topic_id>/', topic , name='topic'),
     path('new_topic/', new_topic , name='new_topic'),
     path('new_entry/<int:topic_id>/', new_entry , name='new_entry'),
     path('edit_entry/<int:entry_id>/', edit_entry, name='edit_entry')
]